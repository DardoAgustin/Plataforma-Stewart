/**
 * S T E W A R T    P L A T F O R M    O N    E S P 3 2
 *
 * Copyright (C) 2019  Nicolas Jeanmonod, ouilogique.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */

#include <Hexapod_Servo.h>
#include <Hexapod_GPIO.h>

#define COUNT_OF(x) ((sizeof(x) / sizeof(0 [x])) / ((size_t)(!(sizeof(x) % sizeof(0 [x])))))

extern angle_t servo_angles[NB_SERVOS];
extern Hexapod_GPIO hx_gpio;

/**
 *
 */
Hexapod_Servo::Hexapod_Servo()
{
}

/**
 *
 */
void Hexapod_Servo::setupServo()
{
    /*Wire.begin();          // Wire must be started first
    Wire.setClock(100000); // Supported baud rates are 100kHz, 400kHz, and 1000kHz

    pwmController.resetDevices();      // Software resets all PCA9685 devices on Wire line
    pwmController.init(B000001);       // Address pins A5-A0 set to B000000
    pwmController.setPWMFrequency(50); // Default is 200Hz, supports 24Hz to 1526Hz

    int8_t movOK = home(servo_angles);
    this->updateServos(movOK);
    delay(500);
        TODA ESTA PARTE ES OARA EL CONTROLADOR DE LOS SERVOMOTORES, COMO NO LO USAMOS, LO BORRAMOS.*/

        // Inicializar los 6 servos
    for (uint8_t sid = 0; sid < NB_SERVOS; sid++) {
        servos[sid].attach(PIN_SERVO[sid], 500, 2500);
    }

    int8_t movOK = home(servo_angles);
    this->updateServos(movOK);
    delay(500); 
}

/**
 * Set servo values to the angles in servo_angles[].
 */
void Hexapod_Servo::updateServos(int8_t movOK, unsigned long safetyWait_ms)
{
    static double nbMov = 0;
    static double nbMovNOK = 0;
    static double NOKrate = 0;
    nbMov++;

    if (movOK == 0)
    {
        static unsigned long T1;
        while ((millis() - T1) < safetyWait_ms) { }
        T1 = millis();

        // Write to servos usando GRADOS
        for (uint8_t sid = 0; sid < NB_SERVOS; sid++)
        {
            // Usamos el angulo en grados que calculó la librería
            servos[sid].write(servo_angles[sid].deg);
        }
    }
    else
    {
        hx_gpio.setBuiltInLED();
        nbMovNOK++;
        NOKrate = (nbMovNOK / nbMov) * (double)100.0;
        Serial.printf("%10lu", millis());
        Serial.printf(" | BAD MOVE | movOK = %d", movOK);
        Serial.printf(" | NB MOV = %10.0f", nbMov);
        Serial.printf(" | NOK rate = %4.1f %%", NOKrate);
        Serial.print("\n");
    }

    hx_gpio.clearBuiltInLEDDelayed(20);
}
/**
 * Set servo values to the angles in servo_angles[].
 */

/**
 *
 */
void Hexapod_Servo::printServoAngles()
{
    Serial.print("\nSERVO COORD        = ");
    Serial.print(getHX_X());
    Serial.print(" ");
    Serial.print(getHX_Y());
    Serial.print(" ");
    Serial.print(getHX_Z());
    Serial.print(" ");
    Serial.print(getHX_A());
    Serial.print(" ");
    Serial.print(getHX_B());
    Serial.print(" ");
    Serial.print(getHX_C());

    Serial.print("\nSERVO_ANGLES (rad) = ");
    for (uint8_t sid = 0; sid < NB_SERVOS; sid++)
    {
        Serial.print(servo_angles[sid].deg);
        Serial.print(" ");
    }

    Serial.print("\nSERVO_ANGLES (us) = ");
    for (uint8_t sid = 0; sid < NB_SERVOS; sid++)
    {
        Serial.print(servo_angles[sid].us);
        Serial.print(" ");
    }

    Serial.print("\nSERVO_ANGLES (debug) = ");
    for (uint8_t sid = 0; sid < NB_SERVOS; sid++)
    {
        Serial.print(servo_angles[sid].debug);
        Serial.print(" ");
    }
    Serial.print("\n");
}

/**
 *
 */
void Hexapod_Servo::printJointAndServoAxisCoord()
{
    Serial.println("P_COORDS");
    for (uint8_t sid = 0; sid < NB_SERVOS; sid++)
    {
        Serial.print(P_COORDS[sid][0]);
        Serial.print("  ");
        Serial.println(P_COORDS[sid][1]);
    }

    Serial.println("\nB_COORDS");
    for (uint8_t sid = 0; sid < NB_SERVOS; sid++)
    {
        Serial.print(B_COORDS[sid][0]);
        Serial.print("  ");
        Serial.println(B_COORDS[sid][1]);
    }
}